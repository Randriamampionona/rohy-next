export { default as Intro } from "./Intro/Intro";
export { default as Apps } from "./Apps/Apps";
export { default as Prices } from "./Prices/Prices";
