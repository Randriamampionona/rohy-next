import styles from "../../styles/Offers.module.scss";

const OffersPage = () => {
	return <main className={styles["offers-page-container"]}>OffersPage</main>;
};

export default OffersPage;
