import styles from "../../styles/Contact.module.scss";

const ContactPage = () => {
	return (
		<main className={styles["contact-page-container"]}>ContactPage</main>
	);
};

export default ContactPage;
