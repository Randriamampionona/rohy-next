import styles from "../../styles/AppsPage.module.scss";

const AppsPage = () => {
	return <main className={styles["apps-page-container"]}>AppsPage</main>;
};

export default AppsPage;
